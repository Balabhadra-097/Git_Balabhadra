let fontSize = 10; 
        const textElement = document.getElementById('text');

        const increaseFontSize = setInterval(() => {
            if (fontSize < 50) {
                fontSize++; 
                textElement.style.fontSize = fontSize + 'pt'; 
            } else {
                clearInterval(increaseFontSize);
                textElement.textContent = 'Smaller Text'; 
                textElement.style.color = 'green'; 
                
                const decreaseFontSize = setInterval(() => {
                    if (fontSize > 5) {
                        fontSize--; 
                        textElement.style.fontSize = fontSize + 'pt'; 
                    } else {
                        clearInterval(decreaseFontSize); 
                    }
                }, 10); 
            }
        }, 10); 