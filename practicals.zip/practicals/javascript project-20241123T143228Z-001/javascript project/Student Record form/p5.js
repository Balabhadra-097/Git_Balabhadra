function validateForm() {
    document.getElementById('nameError').innerText = '';
    document.getElementById('ageError').innerText = '';
    document.getElementById('emailError').innerText = '';
    document.getElementById('courseError').innerText = '';
    document.getElementById('genderError').innerText = '';
    document.getElementById('successMessage').innerText = '';

    const name = document.getElementById('studentName').value.trim();
    const age = document.getElementById('studentAge').value;
    const email = document.getElementById('studentEmail').value.trim();
    const course = document.getElementById('studentCourse').value;
    const gender = document.getElementById('studentGender').value;

    let valid = true;

    if (name === '') {
        document.getElementById('nameError').innerText = 'Name is required.';
        valid = false;
    }

    if (age === '' || age < 1 || age > 120) {
        document.getElementById('ageError').innerText = 'Please enter a valid age (1-120).';
        valid = false;
    }

    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (email === '' || !emailPattern.test(email)) {
        document.getElementById('emailError').innerText = 'Please enter a valid email address.';
        valid = false;
    }

    if (course === '') {
        document.getElementById('courseError').innerText}
    }