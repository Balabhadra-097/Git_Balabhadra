// Function to remove a character at a specified position
function removeCharacterAtPosition(str, position) {
    if (position < 0 || position >= str.length) {
        return "Invalid position";
    }
    return str.slice(0, position) + str.slice(position + 1);
}

// Function to change the case of a string
function changeCase(str) {
    let newStr = '';
    for (let char of str) {
        if (char === char.toUpperCase()) {
            newStr += char.toLowerCase();
        } else {
            newStr += char.toUpperCase();
        }
    }
    return newStr;
}

function manipulateString() {
    const inputString = document.getElementById('inputString').value;
    const positionToRemove = parseInt(document.getElementById('removePosition').value, 10);
    
    const newString = removeCharacterAtPosition(inputString, positionToRemove);
    const caseChangedString = changeCase(inputString);

    document.getElementById('results').innerHTML = `
        <p>Original String: ${inputString}</p>
        <p>String after removing character at position ${positionToRemove}: ${newString}</p>
        <p>String with changed case: ${caseChangedString}</p>
    `;
}