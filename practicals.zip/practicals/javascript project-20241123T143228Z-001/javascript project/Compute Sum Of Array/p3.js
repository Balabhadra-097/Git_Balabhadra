 function computeSum() {
    const input = document.getElementById('arrayInput').value;
    const numArray = input.split(',').map(Number); 
    if (numArray.some(isNaN)) {
        document.getElementById('result').innerText = "Please enter valid integers.";
        return;
    }

    const sum = numArray.reduce((accumulator, currentValue) => accumulator + currentValue, 0);
    document.getElementById('result').innerText = `Sum of elements: ${sum}`;}