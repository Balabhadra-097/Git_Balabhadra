function calculateCountdown() {
    const birthdayInput = document.getElementById('birthdayInput').value;
    const currentYear = new Date().getFullYear();
    const today = new Date();
    let birthdayDate = new Date(`${currentYear}/${birthdayInput}`);

   
    if (birthdayDate < today) {
        birthdayDate.setFullYear(currentYear + 1);
    }

    const timeDiff = birthdayDate - today;
    const daysDiff = Math.ceil(timeDiff / (1000 * 60 * 60 * 24));

    const countdownDisplay = document.getElementById('countdownDisplay');
    if (daysDiff >= 0) {
        countdownDisplay.innerText = `Days until your birthday: ${daysDiff}`;
    } else {
        countdownDisplay.innerText = "Please enter a valid date.";
    }
}