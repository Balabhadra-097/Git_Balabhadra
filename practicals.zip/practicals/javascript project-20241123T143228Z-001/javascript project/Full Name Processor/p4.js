function processFullName() {
    const fullName = document.getElementById('fullNameInput').value.trim();
    const nameParts = fullName.split(' ');

    // Default values
    let firstName = "NA";
    let middleName = "NA";
    let lastName = "NA";

    if (nameParts.length > 0) {
        firstName = nameParts[0]; // First name is always the first part

        if (nameParts.length === 2) {
            lastName = nameParts[1]; // Last name if there are only two parts
        } else if (nameParts.length > 2) {
            lastName = nameParts[nameParts.length - 1]; // Last name is the last part
            middleName = nameParts.slice(1, nameParts.length - 1).join(' '); // Middle names are the parts in between
        }
    }

    // Update the labels with the names
    document.getElementById('firstName').innerText = firstName;
    document.getElementById('middleName').innerText = middleName;
    document.getElementById('lastName').innerText = lastName;
}